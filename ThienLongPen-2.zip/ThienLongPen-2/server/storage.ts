import { 
  products, 
  testingRequests, 
  contactMessages,
  type Product, 
  type InsertProduct,
  type TestingRequest,
  type InsertTestingRequest,
  type ContactMessage,
  type InsertContactMessage
} from "@shared/schema";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  
  // Testing Requests
  createTestingRequest(request: InsertTestingRequest): Promise<TestingRequest>;
  getTestingRequests(): Promise<TestingRequest[]>;
  
  // Contact Messages
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private testingRequests: Map<number, TestingRequest>;
  private contactMessages: Map<number, ContactMessage>;
  private currentProductId: number;
  private currentTestingRequestId: number;
  private currentContactMessageId: number;

  constructor() {
    this.products = new Map();
    this.testingRequests = new Map();
    this.contactMessages = new Map();
    this.currentProductId = 1;
    this.currentTestingRequestId = 1;
    this.currentContactMessageId = 1;
    
    // Initialize with sample products
    this.initializeProducts();
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Bút Bi Thiên Long TL-079",
        description: "Bút bi cao cấp, mực êm mượt, thiết kế sang trọng",
        price: "15.000đ",
        category: "Bút Bi",
        imageUrl: "/assets/bút cao cấp_1749525970849.jpg",
        rating: "5.0"
      },
      {
        name: "Bút Mực Thiên Long TL-036",
        description: "Bút mực học sinh, viết mượt, không lem",
        price: "8.000đ",
        category: "Bút Mực",
        imageUrl: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "4.0"
      },
      {
        name: "Bút Chì Kim TL-125",
        description: "Bút chì kim 0.5mm, thiết kế ergonomic",
        price: "12.000đ",
        category: "Bút Chì",
        imageUrl: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "5.0"
      },
      {
        name: "Bộ Bút Premium",
        description: "Bộ sưu tập cao cấp, hộp quà sang trọng",
        price: "150.000đ",
        category: "Cao Cấp",
        imageUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
        rating: "5.0"
      },
      {
        name: "Bút Bi TL-027",
        description: "Bút bi đa năng, phù hợp mọi lứa tuổi",
        price: "5.000đ",
        category: "Bút Bi",
        imageUrl: "/assets/bút bi_1749526074124.jpg",
        rating: "4.5"
      },
      {
        name: "Bút Mực TL-089",
        description: "Bút mực cao cấp với ngòi thép không gỉ",
        price: "25.000đ",
        category: "Bút Mực",
        imageUrl: "/assets/bút mực_1749526126269.jpg",
        rating: "4.8"
      }
    ];

    sampleProducts.forEach(product => {
      const id = this.currentProductId++;
      this.products.set(id, { ...product, id, available: true });
    });
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return Array.from(this.products.values()).filter(
      product => product.category === category
    );
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createTestingRequest(insertRequest: InsertTestingRequest): Promise<TestingRequest> {
    const id = this.currentTestingRequestId++;
    const request: TestingRequest = {
      ...insertRequest,
      id,
      createdAt: new Date(),
    };
    this.testingRequests.set(id, request);
    return request;
  }

  async getTestingRequests(): Promise<TestingRequest[]> {
    return Array.from(this.testingRequests.values());
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentContactMessageId++;
    const message: ContactMessage = {
      ...insertMessage,
      id,
      createdAt: new Date(),
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }
}

export const storage = new MemStorage();
