import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTestingRequestSchema, insertContactMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Lỗi khi tải sản phẩm" });
    }
  });

  // Get products by category
  app.get("/api/products/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      console.error("Error fetching products by category:", error);
      res.status(500).json({ message: "Lỗi khi tải sản phẩm theo danh mục" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID sản phẩm không hợp lệ" });
      }
      
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: "Không tìm thấy sản phẩm" });
      }
      
      res.json(product);
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Lỗi khi tải thông tin sản phẩm" });
    }
  });

  // Create testing request
  app.post("/api/testing-requests", async (req, res) => {
    try {
      const validatedData = insertTestingRequestSchema.parse(req.body);
      const testingRequest = await storage.createTestingRequest(validatedData);
      res.status(201).json(testingRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Dữ liệu không hợp lệ", 
          errors: error.errors 
        });
      }
      console.error("Error creating testing request:", error);
      res.status(500).json({ message: "Lỗi khi tạo yêu cầu nhận bút thử" });
    }
  });

  // Get all testing requests (for admin purposes)
  app.get("/api/testing-requests", async (req, res) => {
    try {
      const requests = await storage.getTestingRequests();
      res.json(requests);
    } catch (error) {
      console.error("Error fetching testing requests:", error);
      res.status(500).json({ message: "Lỗi khi tải danh sách yêu cầu" });
    }
  });

  // Create contact message
  app.post("/api/contact-messages", async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const contactMessage = await storage.createContactMessage(validatedData);
      res.status(201).json(contactMessage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Dữ liệu không hợp lệ", 
          errors: error.errors 
        });
      }
      console.error("Error creating contact message:", error);
      res.status(500).json({ message: "Lỗi khi gửi tin nhắn liên hệ" });
    }
  });

  // Get all contact messages (for admin purposes)
  app.get("/api/contact-messages", async (req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ message: "Lỗi khi tải tin nhắn liên hệ" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
