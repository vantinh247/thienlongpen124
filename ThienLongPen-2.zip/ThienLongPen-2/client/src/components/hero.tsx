import { Button } from "@/components/ui/button";
import { Gift, ArrowRight } from "lucide-react";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-br from-brand-blue to-blue-700 text-white">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h2 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              Bút Viết <span className="text-yellow-400">Thiên Long</span>
              <br />Chất Lượng Hàng Đầu
            </h2>
            <p className="text-xl mb-8 text-blue-100 leading-relaxed">
              Trải nghiệm ngay tại nhà với chương trình "Nhận Bút Về Nhà Làm". 
              Hoàn toàn miễn phí, không cam kết mua hàng.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={() => scrollToSection("testing")}
                className="bg-brand-red hover:bg-red-700 text-white px-8 py-4 text-lg font-semibold transform hover:scale-105 transition-all shadow-lg"
              >
                <Gift className="mr-2 h-5 w-5" />
                Nhận Bút Miễn Phí
              </Button>
              <Button 
                onClick={() => scrollToSection("products")}
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-brand-blue px-8 py-4 text-lg font-semibold"
              >
                Xem Sản Phẩm
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
              <img 
                src="https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Bút viết cao cấp Thiên Long" 
                className="w-full h-64 object-cover rounded-xl shadow-2xl mb-4"
              />
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-2">Bộ Sưu Tập Cao Cấp</h3>
                <p className="text-blue-100">Từ bút bi đến bút mực, đáp ứng mọi nhu cầu viết</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
