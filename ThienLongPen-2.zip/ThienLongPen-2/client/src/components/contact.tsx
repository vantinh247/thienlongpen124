import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send,
  Facebook,
  Twitter,
  Instagram,
  Youtube
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { InsertContactMessage } from "@shared/schema";

const formSchema = z.object({
  fullName: z.string().min(2, "Họ tên phải có ít nhất 2 ký tự"),
  email: z.string().email("Email không hợp lệ"),
  phoneNumber: z.string().optional(),
  subject: z.string().min(1, "Vui lòng chọn chủ đề"),
  message: z.string().min(10, "Nội dung phải có ít nhất 10 ký tự"),
});

type FormData = z.infer<typeof formSchema>;

export default function Contact() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phoneNumber: "",
      subject: "",
      message: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertContactMessage) => {
      const response = await apiRequest("POST", "/api/contact-messages", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Gửi tin nhắn thành công!",
        description: "Chúng tôi sẽ phản hồi trong thời gian sớm nhất.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/contact-messages"] });
    },
    onError: () => {
      toast({
        title: "Có lỗi xảy ra",
        description: "Vui lòng thử lại sau hoặc liên hệ hotline 1900 1234",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Địa Chỉ",
      details: ["123 Đường ABC, Quận 1, TP.HCM", "456 Phố XYZ, Hoàn Kiếm, Hà Nội"],
    },
    {
      icon: Phone,
      title: "Điện Thoại",
      details: ["Hotline: 1900 1234", "Zalo: 0123 456 789"],
    },
    {
      icon: Mail,
      title: "Email",
      details: ["info@thienlong.com.vn", "support@thienlong.com.vn"],
    },
    {
      icon: Clock,
      title: "Giờ Làm Việc",
      details: ["Thứ 2 - Thứ 6: 8:00 - 17:00", "Thứ 7: 8:00 - 12:00"],
    },
  ];

  const subjects = [
    "Tư vấn sản phẩm",
    "Chương trình nhận bút",
    "Phản hồi dịch vụ",
    "Hợp tác kinh doanh",
    "Khác",
  ];

  const socialMedia = [
    { icon: Facebook, color: "bg-blue-600 hover:bg-blue-700" },
    { icon: Twitter, color: "bg-blue-400 hover:bg-blue-500" },
    { icon: Instagram, color: "bg-pink-500 hover:bg-pink-600" },
    { icon: Youtube, color: "bg-red-600 hover:bg-red-700" },
  ];

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Liên Hệ Với Chúng Tôi</h2>
          <p className="text-xl text-brand-gray">Chúng tôi luôn sẵn sàng hỗ trợ và tư vấn cho bạn</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="shadow-sm">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Thông Tin Liên Hệ</h3>
                
                <div className="space-y-6">
                  {contactInfo.map((info, index) => {
                    const IconComponent = info.icon;
                    return (
                      <div key={index} className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-brand-blue/10 rounded-lg flex items-center justify-center flex-shrink-0">
                          <IconComponent className="text-brand-blue h-6 w-6" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-1">{info.title}</h4>
                          {info.details.map((detail, detailIndex) => (
                            <p key={detailIndex} className="text-brand-gray">{detail}</p>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card className="shadow-sm">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Kết Nối Với Chúng Tôi</h3>
                <div className="flex space-x-4">
                  {socialMedia.map((social, index) => {
                    const IconComponent = social.icon;
                    return (
                      <button
                        key={index}
                        className={`w-12 h-12 rounded-lg flex items-center justify-center text-white transition-colors ${social.color}`}
                      >
                        <IconComponent className="w-5 h-5" />
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Form */}
          <Card className="shadow-sm">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Gửi Tin Nhắn</h3>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Họ Tên *</FormLabel>
                          <FormControl>
                            <Input 
                              {...field}
                              className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Số Điện Thoại</FormLabel>
                          <FormControl>
                            <Input 
                              {...field}
                              className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email *</FormLabel>
                        <FormControl>
                          <Input 
                            type="email"
                            {...field}
                            className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="subject"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Chủ Đề</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue">
                              <SelectValue placeholder="Chọn chủ đề" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {subjects.map((subject) => (
                              <SelectItem key={subject} value={subject}>
                                {subject}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nội Dung *</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Nhập nội dung tin nhắn..."
                            className="resize-none h-32 focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    disabled={mutation.isPending}
                    className="w-full bg-brand-blue hover:bg-blue-700 text-white py-4 text-lg font-semibold transition-all"
                  >
                    {mutation.isPending ? (
                      "Đang gửi..."
                    ) : (
                      <>
                        <Send className="mr-2 h-5 w-5" />
                        Gửi Tin Nhắn
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
