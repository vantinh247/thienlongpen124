import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, ArrowRight } from "lucide-react";
import type { Product } from "@shared/schema";

export default function ProductShowcase() {
  const [selectedCategory, setSelectedCategory] = useState("Tất Cả");

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const categories = ["Tất Cả", "Bút Bi", "Bút Mực", "Bút Chì", "Cao Cấp"];

  const filteredProducts = selectedCategory === "Tất Cả" 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const scrollToTesting = () => {
    const element = document.getElementById("testing");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Bút Bi": return "bg-blue-100 text-brand-blue";
      case "Bút Mực": return "bg-green-100 text-green-700";
      case "Bút Chì": return "bg-purple-100 text-purple-700";
      case "Cao Cấp": return "bg-yellow-100 text-yellow-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const renderStars = (rating: string) => {
    const ratingNum = parseFloat(rating);
    const fullStars = Math.floor(ratingNum);
    const hasHalfStar = ratingNum % 1 !== 0;
    
    return (
      <div className="flex text-yellow-400">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={i} className="w-4 h-4 fill-current" />
        ))}
        {hasHalfStar && <Star className="w-4 h-4 fill-current opacity-50" />}
        {[...Array(5 - Math.ceil(ratingNum))].map((_, i) => (
          <Star key={i + fullStars} className="w-4 h-4" />
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <section id="products" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">
              <div className="h-8 bg-gray-200 rounded w-64 mx-auto mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-96 mx-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Sản Phẩm Nổi Bật</h2>
          <p className="text-xl text-brand-gray max-w-2xl mx-auto">
            Khám phá bộ sưu tập bút viết đa dạng từ Thiên Long, 
            được tin dùng bởi hàng triệu người Việt
          </p>
        </div>

        {/* Product Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
              className={`px-6 py-2 rounded-full font-medium transition-colors ${
                selectedCategory === category
                  ? "bg-brand-blue text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-brand-blue hover:text-white"
              }`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-xl transition-shadow">
              <div className="relative">
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-t-xl"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <Badge className={getCategoryColor(product.category)}>
                    {product.category}
                  </Badge>
                  {renderStars(product.rating)}
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                <p className="text-brand-gray text-sm mb-4">{product.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-brand-red font-bold text-lg">{product.price}</span>
                  <Button 
                    onClick={scrollToTesting}
                    className="bg-brand-blue text-white hover:bg-blue-700 transition-colors"
                    size="sm"
                  >
                    Nhận Thử
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="outline"
            className="bg-gray-100 text-brand-blue hover:bg-gray-200 px-8 py-3 font-semibold"
          >
            Xem Thêm Sản Phẩm 
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  );
}
