import { Facebook, Instagram, Youtube } from "lucide-react";

export default function Footer() {
  const productLinks = [
    "Bút Bi",
    "Bút Mực", 
    "Bút Chì Kim",
    "Bộ Bút Cao Cấp",
    "Phụ Kiện",
  ];

  const serviceLinks = [
    "Nhận Bút Về Nhà",
    "Tư Vấn Miễn Phí",
    "Bảo Hành",
    "Đổi Trả",
    "Giao Hàng",
  ];

  const supportLinks = [
    "Liên Hệ",
    "FAQ",
    "Chính Sách",
    "Điều Khoản",
    "Sitemap",
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <button 
              onClick={scrollToTop}
              className="flex items-center space-x-3 mb-4 hover:opacity-80 transition-opacity"
            >
              <div className="w-10 h-10 bg-brand-blue rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">TL</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">Thiên Long</h3>
                <p className="text-sm text-gray-400">Bút Viết Chất Lượng</p>
              </div>
            </button>
            <p className="text-gray-300 mb-4">
              Thương hiệu bút viết hàng đầu Việt Nam với hơn 30 năm kinh nghiệm, 
              cam kết mang đến sản phẩm chất lượng cao nhất.
            </p>
            <div className="flex space-x-3">
              <button className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center text-gray-300 hover:bg-brand-blue hover:text-white transition-colors">
                <Facebook className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center text-gray-300 hover:bg-brand-blue hover:text-white transition-colors">
                <Instagram className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 bg-gray-700 rounded-lg flex items-center justify-center text-gray-300 hover:bg-brand-blue hover:text-white transition-colors">
                <Youtube className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Sản Phẩm</h4>
            <ul className="space-y-2 text-gray-300">
              {productLinks.map((link) => (
                <li key={link}>
                  <button className="hover:text-white transition-colors text-left">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Dịch Vụ</h4>
            <ul className="space-y-2 text-gray-300">
              {serviceLinks.map((link) => (
                <li key={link}>
                  <button className="hover:text-white transition-colors text-left">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Hỗ Trợ</h4>
            <ul className="space-y-2 text-gray-300">
              {supportLinks.map((link) => (
                <li key={link}>
                  <button className="hover:text-white transition-colors text-left">
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Thiên Long. Tất cả quyền được bảo lưu.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <button className="text-gray-400 hover:text-white text-sm transition-colors">
                Chính Sách Bảo Mật
              </button>
              <button className="text-gray-400 hover:text-white text-sm transition-colors">
                Điều Khoản Sử Dụng
              </button>
              <button className="text-gray-400 hover:text-white text-sm transition-colors">
                Cookie
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
