import { Award, Truck, Headphones, Leaf } from "lucide-react";

export default function About() {
  const features = [
    {
      icon: Award,
      title: "Chất Lượng Đảm Bảo",
      description: "Sản phẩm được kiểm tra nghiêm ngặt",
    },
    {
      icon: Truck,
      title: "Giao Hàng Nhanh",
      description: "Miễn phí vận chuyển toàn quốc",
    },
    {
      icon: Headphones,
      title: "Hỗ Trợ 24/7",
      description: "Tư vấn nhiệt tình, chuyên nghiệp",
    },
  ];

  const stats = [
    { value: "30+", label: "Năm Kinh Nghiệm" },
    { value: "100+", label: "Sản Phẩm" },
    { value: "5M+", label: "Khách Hàng" },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Về Thiên Long</h2>
            <p className="text-lg text-brand-gray mb-6 leading-relaxed">
              Với hơn 30 năm kinh nghiệm trong ngành văn phòng phẩm, Thiên Long đã trở thành 
              thương hiệu bút viết hàng đầu Việt Nam, được tin dùng bởi hàng triệu khách hàng.
            </p>
            
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-brand-blue/10 rounded-lg flex items-center justify-center">
                      <IconComponent className="text-brand-blue h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{feature.title}</h3>
                      <p className="text-brand-gray">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-200">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-brand-blue mb-1">{stat.value}</div>
                  <div className="text-sm text-brand-gray">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Văn phòng hiện đại với văn phòng phẩm cao cấp" 
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-lg p-6 max-w-xs">
              <div className="flex items-center space-x-3 mb-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Leaf className="text-green-600 h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Thân Thiện Môi Trường</h4>
                  <p className="text-sm text-brand-gray">Cam kết bảo vệ môi trường</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
