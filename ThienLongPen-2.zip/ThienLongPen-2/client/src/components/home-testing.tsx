import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, Star, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import type { InsertTestingRequest } from "@shared/schema";

const formSchema = z.object({
  fullName: z.string().min(2, "Họ tên phải có ít nhất 2 ký tự"),
  phoneNumber: z.string().min(10, "Số điện thoại phải có ít nhất 10 số"),
  address: z.string().min(10, "Địa chỉ phải có ít nhất 10 ký tự"),
  penType: z.string().min(1, "Vui lòng chọn loại bút"),
  notes: z.string().optional(),
  agreedToTerms: z.boolean().refine(val => val === true, "Bạn phải đồng ý với điều khoản"),
});

type FormData = z.infer<typeof formSchema>;

export default function HomeTesting() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      phoneNumber: "",
      address: "",
      penType: "",
      notes: "",
      agreedToTerms: false,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertTestingRequest) => {
      const response = await apiRequest("POST", "/api/testing-requests", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Đăng ký thành công!",
        description: "Chúng tôi sẽ liên hệ với bạn trong vòng 24h để xác nhận thông tin.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/testing-requests"] });
    },
    onError: () => {
      toast({
        title: "Có lỗi xảy ra",
        description: "Vui lòng thử lại sau hoặc liên hệ hotline 1900 1234",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  const benefits = [
    "Hoàn toàn miễn phí, không phí vận chuyển",
    "Trải nghiệm tại nhà trong 7 ngày",
    "Không cam kết mua hàng",
    "Tư vấn 1-1 từ chuyên gia",
  ];

  const penTypes = [
    "Bút bi thường",
    "Bút mực học sinh",
    "Bút chì kim",
    "Bộ bút cao cấp",
    "Tất cả các loại",
  ];

  return (
    <section id="testing" className="py-20 bg-gradient-to-r from-brand-blue to-blue-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white">
            <h2 className="text-4xl font-bold mb-6">Nhận Bút Về Nhà Làm</h2>
            <div className="space-y-4 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="text-green-400 mt-1 h-5 w-5 flex-shrink-0" />
                  <p className="text-lg">{benefit}</p>
                </div>
              ))}
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6">
              <h3 className="font-semibold text-lg mb-2">Đã có hơn 50,000+ khách hàng tin tưởng</h3>
              <div className="flex items-center space-x-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span className="text-white/80">4.9/5 từ 12,460 đánh giá</span>
              </div>
            </div>
          </div>

          {/* Registration Form */}
          <div className="bg-white rounded-2xl shadow-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Đăng Ký Nhận Bút Miễn Phí
            </h3>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Họ và Tên *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Nhập họ tên đầy đủ" 
                          {...field}
                          className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phoneNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Số Điện Thoại *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="0123 456 789" 
                          {...field}
                          className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Địa Chỉ Nhận Hàng *</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Nhập địa chỉ chi tiết để giao hàng"
                          className="resize-none focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="penType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Loại Bút Quan Tâm</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="focus:ring-2 focus:ring-brand-blue focus:border-brand-blue">
                            <SelectValue placeholder="Chọn loại bút" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {penTypes.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ghi Chú</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Yêu cầu đặc biệt hoặc câu hỏi"
                          className="resize-none focus:ring-2 focus:ring-brand-blue focus:border-brand-blue"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="agreedToTerms"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-brand-blue data-[state=checked]:border-brand-blue"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-sm text-gray-600">
                          Tôi đồng ý với{" "}
                          <button type="button" className="text-brand-blue underline">
                            điều khoản và điều kiện
                          </button>{" "}
                          của chương trình nhận bút về nhà làm
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={mutation.isPending}
                  className="w-full bg-brand-red hover:bg-red-700 text-white py-4 text-lg font-semibold transform hover:scale-105 transition-all shadow-lg"
                >
                  {mutation.isPending ? (
                    "Đang gửi..."
                  ) : (
                    <>
                      <Send className="mr-2 h-5 w-5" />
                      Gửi Đăng Ký Ngay
                    </>
                  )}
                </Button>
              </form>
            </Form>
            
            <p className="text-center text-sm text-gray-500 mt-4">
              Chúng tôi sẽ liên hệ trong vòng 24h để xác nhận thông tin
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
