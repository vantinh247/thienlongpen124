import { Card, CardContent } from "@/components/ui/card";
import { Star, User } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      id: 1,
      rating: 5,
      content: "Chương trình nhận bút về nhà thật tuyệt vời. Tôi đã thử nhiều loại bút khác nhau và tìm được cây bút ưng ý nhất. Dịch vụ tận tình, sản phẩm chất lượng cao.",
      author: "Nguyễn Thị Lan",
      position: "Giáo viên, Hà Nội",
    },
    {
      id: 2,
      rating: 5,
      content: "Bút viết rất mượt, thiết kế đẹp. Nhận được bút nhanh chóng, đóng gói cẩn thận. Chắc chắn sẽ mua thêm cho cả gia đình.",
      author: "Trần Văn Minh",
      position: "Doanh nhân, TP.HCM",
    },
    {
      id: 3,
      rating: 4,
      content: "Con tôi rất thích bút chì kim này, viết mượt và không bị gãy. Giá cả hợp lý, chất lượng tốt. Cảm ơn Thiên Long!",
      author: "Lê Thị Hoa",
      position: "Phụ huynh, Đà Nẵng",
    },
  ];

  const renderStars = (rating: number) => {
    return (
      <div className="flex text-yellow-400 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star 
            key={i} 
            className={`w-5 h-5 ${i < rating ? 'fill-current' : ''}`} 
          />
        ))}
      </div>
    );
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Khách Hàng Nói Gì Về Chúng Tôi
          </h2>
          <p className="text-xl text-brand-gray">
            Những chia sẻ chân thực từ khách hàng đã trải nghiệm
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="shadow-sm border border-gray-100">
              <CardContent className="p-6">
                {renderStars(testimonial.rating)}
                <p className="text-gray-700 mb-4 leading-relaxed">
                  "{testimonial.content}"
                </p>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                    <User className="w-5 h-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.author}</p>
                    <p className="text-sm text-brand-gray">{testimonial.position}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
